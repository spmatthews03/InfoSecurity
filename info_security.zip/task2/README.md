#Small key space#

You're given a RSA public key, get the private key.
Complete the two TODOs in "get_pri_key.py".
To run "get_pri_key.py", please run:
	- python get_pri_key.py your_id

Submission:
1. private key, in hex format, replace the "task2" value in submission json. (10)
2. get_pri_key.py file.
3. an explanation about how you get the private key in report. (10)
