bdornier3_submission.json is a template for a submission file, and
it can also be used as a testcase for `bdornier3`.
